import UIKit

// previous array with crocs I have and crocs I want combined
var crocsCollection: [String] = ["Digital Aqua", "Mineral Blue", "Pink Lemonade", "Black", "Lavender", "Fresco", "Lime Zest", "Slate Gray", "White", "Lemon"]

// sorts in alphabetical order
let sortedCorcs = crocsCollection.sorted()
crocsCollection.sort()

print (sortedCorcs)

print ( "I love organized Crocs 😁")
